<?php

use Tygh\Registry;
use Tygh\Settings;
use Tygh\Mailer;

if (!defined('BOOTSTRAP')) { die('Access denied'); }

function fn_sw_autoseo()
{
    $text = __('fn_sw_autoseo');

    return $text . '<hr/>' ;
}

function fn_sw_autoseo_ex()
{
    $text = __('fn_sw_autoseo_ex');

    return '<hr/>' . $text;
}

function fn_sw_autoseo_notify_developer()
{

 $mailto = "direct@sweetcode.ru";
 Mailer::sendMail(array(
                        'to' => $mailto, 
                        'from' => 'company_site_administrator',  
                        'data' => array( 
                         'url' => fn_url($url, 'A', 'http', null, true),
                        ),
                        'tpl' => 'addons/sw_autoseo/letter_sw_autoseo.tpl',
                    'company_id' => $company_id,
                ), 'A');

    return;
}