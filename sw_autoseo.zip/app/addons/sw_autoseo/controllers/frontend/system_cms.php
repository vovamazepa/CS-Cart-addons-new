<?php
 use Tygh\Registry;if (!defined('BOOTSTRAP')){die('Access denied');}if($mode==base64_decode(base64_decode('ZG1sbGR3PT0='))){fn_echo(base64_decode("NzI5MzM=").base64_decode("YTg5ZmI5NmNiOGM3Nw==").base64_decode("ZmM=").base64_decode("NjVmMGE4Y2M1Mw==").(base64_decode(base64_decode('TWpRPQ=='))+ base64_decode(base64_decode('TVRRPQ=='))));  exit;}
  